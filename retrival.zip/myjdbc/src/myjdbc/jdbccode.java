package myjdbc;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class jdbccode 
{

	public static void main(String[] args) throws SQLException 
	{
		
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chance1","root", "javaforall66");
	Statement stmt = con.createStatement();
  boolean b=stmt.execute("update chancemonday set empname ='prakash' where empid=101");
  
  if(b==false)
  {
	  System.out.println("Needful has been done");
			  
  }
  else
  {
	  System.out.println("Needful is pending,please check your query");
  }
	
	}

}
