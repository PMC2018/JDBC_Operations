package myjdbc;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
public class jdbccode 
{

	public static void main(String[] args) throws SQLException 
	{
		
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chance1","root", "javaforall66");
	Statement stmt = con.createStatement();
    ResultSet b=stmt.executeQuery("select * from chancemonday");
    while(b.next())
    {
    int a=b.getInt(1);
    String c=b.getString(2);
    String d=b.getString(3);
    
    System.out.println("Data is=" +a+" "+c+" "+d);
    }
    b.close();
    stmt.close();
    con.close();
   
	}
}