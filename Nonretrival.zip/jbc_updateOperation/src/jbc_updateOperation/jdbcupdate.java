package jbc_updateOperation;
import java.sql.*;
public class jdbcupdate {

	public static void main(String[] args) throws SQLException
	{
		
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chance1","root","javaforall66");
Statement stmt=con.createStatement();
int count =stmt.executeUpdate("update chancemonday set empname='prakash' where empid=101");
if(count==1)
{
	System.out.println("Üpdaye has been doen");
}
else
{
	System.out.println("please check your query");
}


	}

}
